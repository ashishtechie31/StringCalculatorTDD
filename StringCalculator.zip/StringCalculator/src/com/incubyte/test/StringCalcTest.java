package com.incubyte.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.incubyte.calulator.StringCalculator;
import com.incubyte.constants.Constants;

/**
 * 
 * @author Ashish Gupta
 * This test class has all the methods of String calculator Test.
 * 12-Dec-2021
 *
 */
public class StringCalcTest {

	public static void main(String[] args) {
		org.junit.runner.JUnitCore.main("com.incubyte.calulator.StringCalculator");
	}

	@Test
	public void testEmptyString() {
		assertEquals(0,StringCalculator.add(Constants.EMPTY_STRING));
	}

	@Test
	public void testSingleNumber(){
		assertEquals(3, StringCalculator.add("3"));
	}
	@Test
	public void testMultipleNumber(){
		assertEquals(15, StringCalculator.add("1,2,3,4,5"));
	}

	@Test
	public void testSingleNegativeNumber() {
		try {
			StringCalculator.add("-4");
		}
		catch(IllegalArgumentException ex) {
			assertEquals(Constants.NEGATIVE_STR+"-4", ex.getMessage());
		}
	}

	@Test
	public void testMultipleNegativeNumber() {
		try {
			StringCalculator.add("1,-2,3,-4,5");
		}
		catch(IllegalArgumentException ex) {			
			assertEquals(Constants.NEGATIVE_STR+"-2,-4", ex.getMessage());
		}
	}

	@Test
	public void testOtherDelimeter() {
		assertEquals(21, StringCalculator.add("//;\n1;2;3;4;5;6"));
	}

	@Test
	public void testOtherDelimeterHash() {
		assertEquals(21, StringCalculator.add("//#\n1#2#3#4#5#6"));
	}

	@Test
	public void testNewLine() {
		assertEquals(21, StringCalculator.add("1,2,3,\n4,5,\n6"));		
	}

	@Test
	public void testMaxValue(){
		assertEquals(Integer.MAX_VALUE, StringCalculator.add("3,2147483644"));
	}

}

