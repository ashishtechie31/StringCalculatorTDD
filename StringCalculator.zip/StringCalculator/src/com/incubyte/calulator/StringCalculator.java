package com.incubyte.calulator;

import com.incubyte.constants.Constants;

/**
 * 
 * @author Ashish Gupta
 * This method contains common method for String calculator
 * 12-Dec-2021
 *
 */
public class StringCalculator 
{
	private StringCalculator() { //avoid object creation

	}

	public static int add(String numbers) {
		String [] numArr;
		int sum=0; 
		String delimeter = Constants.COMMA ;
		if(Constants.EMPTY_STRING.equals(numbers)) {
			return sum;
		}
		String regex = "//(.*)\n(.*)";
		if(numbers.matches(regex)) {
			delimeter = numbers.substring(2, 3);				
			String numString = numbers.substring(4);			
			numArr = splitNumber(numString,delimeter);
			sum = sum(numArr);
		}
		else if(numbers.contains(delimeter)) {
			numbers= numbers.replace("\n", Constants.EMPTY_STRING);
			numArr = splitNumber(numbers, delimeter);
			sum = sum(numArr);				
		}
		else {
			int num = getIntegerFromString(numbers);
			if(num<0) {
				throw new IllegalArgumentException(Constants.NEGATIVE_STR+num);
			}
			return num;
		}

		return sum;
	}

	private static String [] splitNumber(String numbers,String delimeter) {
		return numbers.split(delimeter);			
	}

	private static int sum(String [] numArr) {
		int sum=0;	
		String negString= Constants.EMPTY_STRING;
		for(String str : numArr) {
			int num = getIntegerFromString(str);
			if(num<0) {
				negString = negString+num+Constants.COMMA;
			}
			if(num<Integer.MAX_VALUE) {
				sum = sum +num;
			}

		}

		if(!Constants.EMPTY_STRING.equals(negString)) {
			if(negString.contains(Constants.COMMA)) {
				negString =  negString.substring(0,negString.length()-1);
			}
			throw new IllegalArgumentException(Constants.NEGATIVE_STR+negString);
		}
		return sum;
	}

	private static int getIntegerFromString(String numStr) {
		return Integer.parseInt(numStr);			
	}
}
