package com.incubyte.constants;

/**
 * 
 * @author Ashish Gupta
 * This class contains constants.
 * 12-DEC-2021
 *
 */
public class Constants {

	public static final String EMPTY_STRING = "";

	public static final String COMMA = ",";

	public static final String NEGATIVE_STR = "Negatives not allowed: ";


	private Constants() { //avoid object creation

	}

}
